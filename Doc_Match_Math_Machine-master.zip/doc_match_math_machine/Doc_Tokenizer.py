from __General_Tools_Module__ import PUNCS


class Micro_Tokenizer:
    def __init__(self, file_name='', text=''):
        if file_name:
            self.file_name = file_name
            self.__load_file_data__()
            self.text = self.Text.lower()
        elif text:
            self.text = text.lower()

        self.__whitespace_tokenize_text__()
        self.__space_out_punc_marks_in_tokens__()
        self.__segregate_character_types__()

    def __retokenize__(self):
        new_tokens = []

        for token in self.tokens:
            if type(token) is list:
                new_tokens.append(token)
            elif type(token) is str:
                new_tokens += token.split()

        self.tokens = new_tokens

    def __load_file_data__(self):
        try:
            with open(self.file_name, 'r', encoding='utf8', 
                      errors='ignore') as f:
                self.Text = f.read()
        except UnicodeDecodeError:
            with open(self.file_name, 'r') as f:
                self.Text = f.read()

    def __whitespace_tokenize_text__(self):
        self.tokens = self.text.split()

    def __space_out_punc_marks_in_tokens__(self):
        for t in range(len(self.tokens)):
            if type(self.tokens[t]) is list:
                continue
            new_string = ''
            for thing in self.tokens[t]:
                if thing in PUNCS:
                    new_string += f' {thing} '
                else:
                    new_string += thing

            self.tokens[t] = new_string.strip()

        self.__retokenize__()

    def __segregate_character_types__(self):
        for t in range(len(self.tokens)):
            element = self.tokens[t]
            new_element = ''
            for i in range(len(element) - 1):
                if element[i].isalpha() and element[i+1].isalpha():
                    new_element += element[i]
                elif element[i].isdigit() and element[i+1].isdigit():
                    new_element += element[i]
                elif element[i] in PUNCS and element[i+1] in PUNCS:
                    new_element += f'{element[i]} '
                else:
                    new_element += f'{element[i]} '

            new_element += element[-1]
            self.tokens[t] = new_element

        self.__retokenize__()


if __name__ == "__main__":
    my_text = """
    This is a simple set of sentences.
    We are only using them to test the micro_tokenizer to see what it does.
    This is only a small simple test.
    """

    mc = Micro_Tokenizer(text=my_text)
    print(mc.tokens)
