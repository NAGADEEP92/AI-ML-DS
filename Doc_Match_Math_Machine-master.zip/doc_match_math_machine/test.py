my_L = ['one', 'two', 'three']

a_L = ['four', 'five']

my_L.append(a_L)
print(my_L)

def retokenize(tokens):
        new_tokens = []

        for token in tokens:
            if type(token) is list:
                new_tokens.append(token)
            elif type(token) is str:
                new_tokens += token.split()

        tokens = new_tokens

        return tokens


my_L = retokenize(my_L)
print(my_L)
