import __General_Tools_Module__ as gtm

fm = gtm.File_Manager(text_dir)  #, exclusion_list=exc_list)

for fn in fm.full_file_list:
    with open(fn, "r") as f:
        the_text = f.read()
    # print(the_text)
    tokens = nltk.sent_tokenize(the_text)
    for i in range(len(tokens[:100])):
        print(f'{i}: {tokens[i]}')
    sys.exit()
