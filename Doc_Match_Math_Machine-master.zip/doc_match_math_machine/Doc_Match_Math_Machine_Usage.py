import __General_Tools_Module__ as gtm
import Doc_Match_Math_Machine_Parts as dm3p
import pprint

pp = pprint.PrettyPrinter(indent=2)


""" Gather Docs for building the corpus """
fm = gtm.File_Manager("./documents")

docs_D = {k: v for k, v in enumerate(fm.full_file_list)}

cm_data_dir = "./cm_data"
mcm = dm3p.Manage_Corpus_Matrix(cm_data_dir)
mcm.grow_corpus_matrix_from_documents(docs_D)

dm3 = dm3p.Doc_Match_Math_Machine(cm_data_dir, top_n=3)

new_file = "doc_100.txt"
new_text = gtm.get_text_from_file(new_file)
matches_D = dm3.get_closest_match_columns(new_text)

pp.pprint(matches_D)
