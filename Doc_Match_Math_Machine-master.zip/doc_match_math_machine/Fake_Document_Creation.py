from faker import Faker


Faker.seed(0)
fake = Faker()

for i in range(100):
   a_doc = fake.paragraph(nb_sentences=20)
   file_name = f'./documents/doc_{i}.txt'
   with open(file_name, 'w') as f:
       f.write(a_doc)
