import __General_Tools_Module__ as gtm
import os
import copy
import numpy as np
import pandas as pd
import scipy.sparse as ss
import scipy.sparse.linalg as ssla
import sys

from Doc_Tokenizer import Micro_Tokenizer


class Corpus_Matrix:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        gtm.prepare_dir(data_dir)

        self.tocab_fn = f'{data_dir}/tocab.json'
        self.cm_fn = f'{data_dir}/cm.npz'

        tocab_exists = os.path.isfile(self.tocab_fn)
        corpus_matrix_exists = os.path.isfile(self.cm_fn)

        check = (tocab_exists and corpus_matrix_exists)

        if check:
            self.tocab = gtm.load_object_from_json_file(self.tocab_fn)
            self.corpus_matrix = ss.load_npz(self.cm_fn)
        else:
            self.tocab = {}

    def add_new_doc_vector(self, tokens):
        previous_token_count = len(self.tocab)
        this_tocab = copy.deepcopy(self.tocab)

        for t in tokens:
            self.tocab[t] = 0
            if t not in this_tocab:
                this_tocab[t] = 0
            this_tocab[t] += 1

        new_token_count = len(self.tocab)

        new_rows = new_token_count - previous_token_count
        tocab_list = list(self.tocab.keys())
        values = this_tocab.values()

        if hasattr(self, "corpus_matrix"):
            self.corpus_matrix = \
                self.__add_zeros_rows_to_bottom_of_matrix__(new_rows)
            column = ss.csc_matrix(
                pd.DataFrame(index=tocab_list, data=values))
            self.corpus_matrix = \
                ss.hstack([self.corpus_matrix, column])
        else:
            self.corpus_matrix = ss.csc_matrix(
                pd.DataFrame(index=tocab_list, data=values))

        ss.save_npz(self.cm_fn, self.corpus_matrix)
        gtm.store_object_to_json_file(self.tocab, self.tocab_fn)

    def replace_vectors_with_vectors(self, del_cols, new_vecs):
        # Extend the matrix rows by the number of rows in new_vecs
        cm_rows = self.corpus_matrix.shape[0]
        new_vecs_rows = new_vecs.shape[0]
        new_rows = new_vecs_rows - cm_rows
        self.__add_zeros_rows_to_bottom_of_matrix__(new_rows)

        # Replace the old columns with the new ones in new_vecs
        ds1 = del_cols[0]
        ds2 = del_cols[-1] + 1
        self.corpus_matrix = ss.hstack(
            [self.corpus_matrix[:, :ds1],
             new_vecs,
             self.corpus_matrix[:, ds2:]])

        self.corpus_matrix = self.remove_zero_rows(self.corpus_matrix)

    def __add_zeros_rows_to_bottom_of_matrix__(self, num_rows):
        cols = self.corpus_matrix.shape[1]
        the_types = self.corpus_matrix.dtype

        new_rows = ss.csc_matrix(np.zeros((num_rows, cols), dtype=the_types))

        # Return a new corpus matrix -
        #     user decides when to update corpus matrix
        corpus_matrix = ss.csc_matrix(ss.vstack(
            [self.corpus_matrix, new_rows]))

        return corpus_matrix

    def remove_zero_rows(self, sparse_csc_matrix):
        # a_sparse_csc_matrix is a scipy sparse csr matrix. We want to remove all zero rows from it
        sparse_csr_matrix = sparse_csc_matrix.tocsr()
        nonzero_row_indice, _ = sparse_csr_matrix.nonzero()
        unique_nonzero_indice = np.unique(nonzero_row_indice)
        sparse_csr_matrix_wo_zero_rows = sparse_csr_matrix[unique_nonzero_indice]
        sparse_csc_matrix = sparse_csr_matrix_wo_zero_rows.tocsc()

        return sparse_csc_matrix


class Manage_Corpus_Matrix:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.cm = Corpus_Matrix(data_dir)

        self.col_to_doc_fn = f'{self.data_dir}/col_to_doc_info.json'
        self.col_to_doc_info_exists = os.path.isfile(self.col_to_doc_fn)

        if self.col_to_doc_info_exists:
            self.col_to_doc_info = \
                gtm.load_object_from_json_file(self.col_to_doc_fn)
        else:
            self.col_to_doc_info = {}

    def grow_corpus_matrix_from_documents(self, docs_D):
        current_doc_ID_list = list(self.col_to_doc_info.values())
        new_doc_IDs = [id for id in docs_D if id not in current_doc_ID_list]
        for doc_ID in new_doc_IDs:
            mt = Micro_Tokenizer(text=docs_D[doc_ID])
            self.cm.add_new_doc_vector(mt.tokens)
            col = self.cm.corpus_matrix.shape[1] - 1

            self.col_to_doc_info[col] = doc_ID

            gtm.store_object_to_json_file(
                self.col_to_doc_info, self.col_to_doc_fn)


class Doc_Match_Math_Machine:
    def __init__(self, cm_data_dir, top_n=3):
        # cm is the corpus matrix of document vectors
        self.cm = Corpus_Matrix(cm_data_dir)
        self.cm.docs_norms = ssla.norm(self.cm.corpus_matrix, axis=0)

        self.col_to_doc_fn = f'{cm_data_dir}/col_to_doc_info.json'
        self.col_to_doc_info_D = gtm.load_object_from_json_file(
            self.col_to_doc_fn)
        self.top_n = top_n

    def get_closest_match_columns(self, doc_text):
        matches_D = {}
        mt_doc = Micro_Tokenizer(text=doc_text)

        doc_tokens = copy.deepcopy(self.cm.tocab)
        num_new_tokens = 0
        for t in mt_doc.tokens:
            if t not in doc_tokens:
                doc_tokens[t] = 0
                num_new_tokens += 1
            doc_tokens[t] += 1
        
        doc_vector = np.array(list(doc_tokens.values()))
        doc_vector = doc_vector.reshape((1, len(doc_vector)))

        doc_vector = ss.csc_matrix(doc_vector, dtype=np.float64)
        doc_norm = ss.linalg.norm(doc_vector)

        ''' Find the closest documents '''
        temp_cm = self.cm.__add_zeros_rows_to_bottom_of_matrix__(
            num_new_tokens)
        ''' ccn = cosine_closeness_numerators
            ccd = cosine_closeness_denominators '''
        ccn = doc_vector * temp_cm
        ccd = doc_norm * self.cm.docs_norms
        simils = ccn / ccd
        simils = np.array(simils)[0]

        the_indices = np.flip(np.argsort(simils))
        the_indices = the_indices[:self.top_n]

        for col in the_indices:
            doc_ID = self.col_to_doc_info_D[str(col)]

            cos = round(simils[col], 6)
            matches_D[cos] = {
                "col": col,
                "doc_ID": doc_ID
            }

        return matches_D
